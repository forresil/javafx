package application;

public class Controller {
	public void onButtonClicked(){
		System.out.println("Auch!");
	}
}
