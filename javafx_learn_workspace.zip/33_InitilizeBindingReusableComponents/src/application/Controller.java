package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;

public class Controller implements Initializable  {

	//Use every time when some code should be executed at program start
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		System.out.println("Loading user data ...");
		
	}

}
